﻿using Microsoft.AspNetCore.Identity.EntityFrameworkCore;
using Microsoft.EntityFrameworkCore;
//using User.Models;




using WebKuaforProje.Models;
using Microsoft.EntityFrameworkCore;
using Microsoft.AspNetCore.Identity.EntityFrameworkCore;
using Microsoft.AspNetCore.Identity;

namespace WebKuaforProje
{
    public class AppDbContext : IdentityDbContext<User>
    {
        public AppDbContext(DbContextOptions<AppDbContext> options)
            : base(options)
        {
        }

        public DbSet<User> Users { get; set; }  // User'ı tanımladık
        public DbSet<Admin> Adminler { get; set; }
        public DbSet<Calisan> Calisanlar { get; set; }
        public DbSet<FotoOneri> FotoOneriler { get; set; }
        public DbSet<Islem> Islemler { get; set; }
        // Musteri yerine User kullanılıyor
        public DbSet<Price> Fiyatlar { get; set; }
        public DbSet<Randevu> Randevular { get; set; }
        public DbSet<Salon> Salonlar { get; set; }

        protected override void OnModelCreating(ModelBuilder modelBuilder)
        {
            base.OnModelCreating(modelBuilder);

            // İlişkileri ve yabancı anahtarları yapılandırma
            modelBuilder.Entity<Randevu>()
                .HasOne(r => r.User)  // User kullanılıyor
                .WithMany(u => u.Randevular)
                .HasForeignKey(r => r.Id)  // Foreign key olarak Id
                .OnDelete(DeleteBehavior.Cascade); // Silme davranışı

            modelBuilder.Entity<Randevu>()
                .HasOne(r => r.Calisan)
                .WithMany(c => c.Randevular)
                .HasForeignKey(r => r.CalisanID)
                .OnDelete(DeleteBehavior.SetNull); // Durumunuza göre değiştirin

            modelBuilder.Entity<Islem>()
                .HasOne(i => i.Salon)
                .WithMany(s => s.Islemler)
                .HasForeignKey(i => i.SalonID)
                .OnDelete(DeleteBehavior.Cascade);

            modelBuilder.Entity<Calisan>()
                .HasOne(c => c.Salon)
                .WithMany(s => s.Calisanlar)
                .HasForeignKey(c => c.SalonID)
                .OnDelete(DeleteBehavior.Cascade);

            modelBuilder.Entity<FotoOneri>()
                .HasOne(f => f.Salon)
                .WithMany(s => s.FotoOneriler)
                .HasForeignKey(f => f.SalonID)
                .OnDelete(DeleteBehavior.Cascade);

            modelBuilder.Entity<FotoOneri>()
                .HasOne(f => f.User)  // User kullanılıyor
                .WithMany(u => u.FotoOneriler)
                .HasForeignKey(f => f.Id)  // Foreign key olarak Id
                .OnDelete(DeleteBehavior.Cascade);

            modelBuilder.Entity<Salon>()
                .HasOne(s => s.Admin)
                .WithMany(a => a.Salonlar)
                .HasForeignKey(s => s.AdminID)
                .OnDelete(DeleteBehavior.Cascade);

            // Sıkça sorgulanan kolonlar üzerinde indeksler ekleyebilirsiniz (isteğe bağlı)
            modelBuilder.Entity<Randevu>()
                .HasIndex(r => r.Id);  // Id üzerinde indeks
            modelBuilder.Entity<Randevu>()
                .HasIndex(r => r.CalisanID);

            modelBuilder.Entity<FotoOneri>()
                .HasIndex(f => f.Id);  // Id üzerinde indeks
            modelBuilder.Entity<FotoOneri>()
                .HasIndex(f => f.SalonID);

            modelBuilder.Entity<Calisan>()
                .HasIndex(c => c.SalonID);
        }
    }
}
