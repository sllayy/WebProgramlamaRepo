using Microsoft.AspNetCore.Mvc;
using Microsoft.EntityFrameworkCore;
using WebKuaforProje;
using WebKuaforProje.Models;

var builder = WebApplication.CreateBuilder(args);

// PostgreSQL ba�lant� dizesi
builder.Services.AddDbContext<AppDbContext>(options =>
    options.UseNpgsql(builder.Configuration.GetConnectionString("DefaultConnection")));

// MVC ve API controller'lar�n� dahil et
builder.Services.AddControllersWithViews();
builder.Services.AddEndpointsApiExplorer();  // API endpoint'lerini ke�fetmek i�in
builder.Services.AddSwaggerGen(); // Swagger dok�mantasyonu i�in

var app = builder.Build();

// Swagger'� geli�tirme ortam�nda aktif et
if (app.Environment.IsDevelopment())
{
    app.UseDeveloperExceptionPage();
    app.UseSwagger();  // Swagger dok�mantasyonu
    app.UseSwaggerUI();  // Swagger aray�z�
}

app.UseHttpsRedirection();
app.UseStaticFiles();

app.UseRouting();

app.UseAuthentication(); // Kullan�c� do�rulama
app.UseAuthorization();  // Yetkilendirme

app.MapControllerRoute(
    name: "default",
    pattern: "{controller=Home}/{action=Index}/{id?}");

app.MapControllers();  // API controller'lar�n� tan�t

app.Run();
