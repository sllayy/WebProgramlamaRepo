﻿using Microsoft.AspNetCore.Mvc;
using WebKuaforProje.Models;
using System.Linq;
using System.Threading.Tasks;

namespace WebKuaforProje.Controllers
{
    public class CalisanController : Controller
    {
        private readonly AppDbContext _context;

        public CalisanController(AppDbContext context)
        {
            _context = context;
        }

        // Çalışanları Listele
        [HttpGet]
        public IActionResult Index()
        {
            var calisanlar = _context.Calisanlar.ToList();
            return View(calisanlar);
        }

        // Yeni Çalışan Ekleme Formu
        [HttpGet]
        public IActionResult Create()
        {
            ViewBag.Salonlar = _context.Salonlar.ToList(); // Salonları Dropdown için gönderiyoruz
            return View();
        }

        // Yeni Çalışan Ekleme
        [HttpPost]
        public async Task<IActionResult> Create(Calisan model)
        {
            if (!ModelState.IsValid)
            {
                ViewBag.Salonlar = _context.Salonlar.ToList();
                return View(model);
            }

            _context.Calisanlar.Add(model);
            await _context.SaveChangesAsync();
            return RedirectToAction("Index");
        }
    }
}
