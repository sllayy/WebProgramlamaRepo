﻿using Microsoft.AspNetCore.Mvc;
using Microsoft.EntityFrameworkCore;
using WebKuaforProje.Models;

namespace WebKuaforProje.Controllers
{
    // API için Route ekliyoruz. Bu sayede "/api/randevu" endpoint'ine istekler alacağız
    [Route("api/[controller]")]
    [ApiController]  // Bu, API controller'ını belirtir ve bazı otomatik özellikleri sağlar
    public class RandevuController : ControllerBase
    {
        private readonly AppDbContext _context;

        public RandevuController(AppDbContext context)
        {
            _context = context;
        }

        // GET: api/randevu
        [HttpGet]
        public async Task<IActionResult> GetRandevular()
        {
            var randevular = await _context.Randevular.Include(r => r.User).Include(r => r.Calisan)
                .ToListAsync();
            return Ok(randevular);  // JSON formatında döner
        }

        // GET: api/randevu/{id}
        [HttpGet("{id}")]
        public async Task<IActionResult> GetRandevu(int id)
        {
            var randevu = await _context.Randevular.Include(r => r.User).Include(r => r.Calisan)
                .FirstOrDefaultAsync(r => r.RandevuID == id);

            if (randevu == null)
            {
                return NotFound();  // 404 döner
            }

            return Ok(randevu);  // JSON formatında döner
        }

        // POST: api/randevu
        [HttpPost]
        public async Task<IActionResult> PostRandevu(Randevu randevu)
        {
            if (ModelState.IsValid)
            {
                _context.Randevular.Add(randevu);
                await _context.SaveChangesAsync();

                return CreatedAtAction(nameof(GetRandevu), new { id = randevu.RandevuID }, randevu);  // 201 döner
            }

            return BadRequest(ModelState);  // 400 döner
        }

        // PUT: api/randevu/{id}
        [HttpPut("{id}")]
        public async Task<IActionResult> PutRandevu(int id, Randevu randevu)
        {
            if (id != randevu.RandevuID)
            {
                return BadRequest();  // 400 döner
            }

            _context.Entry(randevu).State = EntityState.Modified;

            try
            {
                await _context.SaveChangesAsync();
            }
            catch (DbUpdateConcurrencyException)
            {
                if (!RandevuExists(id))
                {
                    return NotFound();  // 404 döner
                }
                else
                {
                    throw;
                }
            }

            return NoContent();  // 204 döner
        }

        // DELETE: api/randevu/{id}
        [HttpDelete("{id}")]
        public async Task<IActionResult> DeleteRandevu(int id)
        {
            var randevu = await _context.Randevular.FindAsync(id);
            if (randevu == null)
            {
                return NotFound();  // 404 döner
            }

            _context.Randevular.Remove(randevu);
            await _context.SaveChangesAsync();

            return NoContent();  // 204 döner
        }

        // Randevu var mı kontrolü (yardımcı metot)
        private bool RandevuExists(int id)
        {
            return _context.Randevular.Any(e => e.RandevuID == id);
        }
    }
}
