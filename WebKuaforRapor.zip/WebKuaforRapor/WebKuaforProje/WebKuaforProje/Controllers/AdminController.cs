﻿using Microsoft.AspNetCore.Mvc;
using WebKuaforProje.Models; // Randevu modelini eklemeyi unutmayın

namespace WebKuaforProje.Controllers
{
    public class AdminController : Controller
    {
        // Admin paneli ana sayfası
        public IActionResult AdminPanel()
        {
            return View();
        }

        // Randevu onay sayfası
        public IActionResult RandevuOnay()
        {
            // Burada, onaylanacak randevuları veritabanından çekebiliriz.
            // Örneğin, randevuların bir listesi burada view'a aktarılabilir.
            return View();
        }

        // Randevu onay işlemi
        [HttpPost]
        public IActionResult ApproveAppointment(int appointmentId)
        {
            

            return RedirectToAction("RandevuOnay"); // Yönlendirme yapılabilir
        }

        // Randevu reddetme işlemi
        [HttpPost]
        public IActionResult RejectAppointment(int appointmentId)
        {
           

            return RedirectToAction("RandevuOnay"); // Yönlendirme yapılabilir
        }
    }
}
