﻿// Price.cs
public class Price
{
    public int PriceID { get; set; }
    public string ServiceName { get; set; }
    public decimal PriceAmount { get; set; }

    public ICollection<Islem> Islemler { get; set; } // Fiyat birden fazla işleme uygulanabilir
}
