﻿// FotoOneri.cs
using WebKuaforProje.Models;

public class FotoOneri
{
    public int FotoOneriID { get; set; }
    public string ImageUrl { get; set; }
    public string Description { get; set; }
    public DateTime DateAdded { get; set; }

    public int SalonID { get; set; }
    public Salon Salon { get; set; } // FotoÖneri bir salona bağlı

    public string? Id { get; set; }
    public User User { get; set; } // Opsiyonel olarak bir müşteriyle ilişkilendirilebilir
}
