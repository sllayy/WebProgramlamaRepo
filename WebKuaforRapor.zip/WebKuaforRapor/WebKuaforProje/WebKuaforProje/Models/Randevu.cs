﻿using System.ComponentModel.DataAnnotations;

namespace WebKuaforProje.Models
{
    public class Randevu
    {
        public int RandevuID { get; set; }

        [Required(ErrorMessage = "Randevu tarihi zorunludur.")]
        [DataType(DataType.Date)]
        [CustomValidation(typeof(Randevu), nameof(ValidateRandevuTarihi))]
        public DateTime RandevuTarihi { get; set; }

        [Required(ErrorMessage = "Hizmet adı zorunludur.")]
        [StringLength(100, ErrorMessage = "Hizmet adı en fazla 100 karakter olabilir.")]
        public string Hizmet { get; set; }

        [Required]
        public string Id { get; set; } // Kullanıcıya ait ID olarak Id
        public User User { get; set; } // User ile ilişkilendirildi

        [Required]
        public int CalisanID { get; set; }
        public Calisan? Calisan { get; set; }

        public static ValidationResult ValidateRandevuTarihi(DateTime tarih, ValidationContext context)
        {
            return tarih >= DateTime.Now
                ? ValidationResult.Success
                : new ValidationResult("Randevu tarihi bugünden önce olamaz.");
        }
    }
}
