﻿using System.ComponentModel.DataAnnotations;
using System.Collections.Generic;

namespace WebKuaforProje.Models
{
    public class Admin
    {
        [Key]
        public int AdminID { get; set; }  // Admin'e özgü ID

        [Required]
        [StringLength(50)]
        public string FullName { get; set; }  // Admin'in tam adı

        [Required]
        [StringLength(100)]
        public string Password { get; set; }  // Admin'in şifresi

        [Required]
        [EmailAddress]
        public string Email { get; set; }  // Admin'in e-posta adresi

        public string Role { get; set; } = "Admin"; // Admin, "Admin" rolüne sahip

        public ICollection<Salon> Salonlar { get; set; } // Admin'in yönettiği salonlar
    }
}
