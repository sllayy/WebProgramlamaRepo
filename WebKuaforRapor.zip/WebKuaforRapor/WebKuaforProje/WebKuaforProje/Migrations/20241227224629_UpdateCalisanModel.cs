﻿using Microsoft.EntityFrameworkCore.Migrations;

#nullable disable

namespace WebKuaforProje.Migrations
{
    public partial class UpdateCalisanModel : Migration
    {
        protected override void Up(MigrationBuilder migrationBuilder)
        {
            migrationBuilder.AddColumn<string>(
                name: "UygunlukSaatleri",
                table: "Calisanlar",
                type: "text",
                nullable: false,
                defaultValue: "");

            migrationBuilder.AddColumn<string>(
                name: "Uzmanlik",
                table: "Calisanlar",
                type: "text",
                nullable: false,
                defaultValue: "");
        }

        protected override void Down(MigrationBuilder migrationBuilder)
        {
            migrationBuilder.DropColumn(
                name: "UygunlukSaatleri",
                table: "Calisanlar");

            migrationBuilder.DropColumn(
                name: "Uzmanlik",
                table: "Calisanlar");
        }
    }
}
