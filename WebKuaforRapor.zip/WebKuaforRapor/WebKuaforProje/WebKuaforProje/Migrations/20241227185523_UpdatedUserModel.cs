﻿using Microsoft.EntityFrameworkCore.Migrations;

#nullable disable

namespace WebKuaforProje.Migrations
{
    public partial class UpdatedUserModel : Migration
    {
        protected override void Up(MigrationBuilder migrationBuilder)
        {

        }

        protected override void Down(MigrationBuilder migrationBuilder)
        {

        }
    }
}
