using Microsoft.AspNetCore.Mvc;
using WebKuaforProje.Models;
using System.Diagnostics;

namespace WebKuaforProje.Controllers
{
    public class HomeController : Controller
    {
        private readonly AppDbContext _context;
        private readonly ILogger<HomeController> _logger;

        public HomeController(AppDbContext context, ILogger<HomeController> logger)
        {
            _context = context;
            _logger = logger;
        }

        // Anasayfa
        public IActionResult Index()
        {
            ViewBag.WelcomeMessage = TempData["WelcomeMessage"];
            return View();
        }


        // Hakk�m�zda sayfas�
        public IActionResult Hakkimizda()
        {
            return View();
        }

        // Fiyat listesi sayfas�
        public IActionResult Fiyatlar()
        {
            return View();
        }

        [ResponseCache(Duration = 0, Location = ResponseCacheLocation.None, NoStore = true)]
        public IActionResult Error()
        {
            return View(new ErrorViewModel { RequestId = Activity.Current?.Id ?? HttpContext.TraceIdentifier });
        }
    }
}