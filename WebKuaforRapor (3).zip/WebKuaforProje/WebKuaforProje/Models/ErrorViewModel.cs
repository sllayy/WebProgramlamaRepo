using Microsoft.EntityFrameworkCore;
using WebKuaforProje.Models;  // ErrorViewModel ve di�er modeller i�in

namespace WebKuaforProje.Models
{
    public class ErrorViewModel
    {
        public string? RequestId { get; set; }

        public bool ShowRequestId => !string.IsNullOrEmpty(RequestId);
    }
}
