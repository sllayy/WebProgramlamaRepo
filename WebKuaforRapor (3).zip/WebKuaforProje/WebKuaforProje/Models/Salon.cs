﻿
using WebKuaforProje.Models; // Eğer User sınıfı burada yer alıyorsa

// Salon.cs
public class Salon
{
    public int SalonID { get; set; }
    public string SalonAdi { get; set; }
    public string Adres { get; set; }
    public string Telefon { get; set; }

    public int AdminID { get; set; }
    public Admin Admin { get; set; } // Salon bir admin tarafından yönetilir

    public ICollection<Calisan> Calisanlar { get; set; }
    public ICollection<FotoOneri> FotoOneriler { get; set; }
    public ICollection<Islem> Islemler { get; set; }
}
