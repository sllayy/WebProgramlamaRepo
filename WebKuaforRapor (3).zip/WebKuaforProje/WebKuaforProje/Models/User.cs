﻿using Microsoft.AspNetCore.Identity;
using System.ComponentModel.DataAnnotations;
using System.Collections.Generic;
using Newtonsoft.Json;
using System.ComponentModel.DataAnnotations.Schema;

namespace WebKuaforProje.Models
{
    public class User : IdentityUser
    {
        

        
        [StringLength(50)]

        public string FullName { get; set; }
       
        public string PhoneNumber { get; set; }
       
        public DateTime DateOfBirth { get; set; }

        [Required]
        public string Gender { get; set; }

        [Required]
        [StringLength(100)]
        public string Password { get; set; }

        [Required]
        [DataType(DataType.Password)]
        [Compare("Password", ErrorMessage = "Parolalar eşleşmiyor.")]
        public string ConfirmPassword { get; set; }

        [Required]
        [EmailAddress]
        public string Email { get; set; }

        
        public string Role { get; set; }

        public string ReturnUrl { get; set; }

        // JSON formatında saklanacak
        public string ExternalLoginsJson { get; set; }

        [NotMapped] // Veritabanına eklenmeyecek, sadece uygulama için
        public List<string> ExternalLogins
        {
            get
            {
                return string.IsNullOrEmpty(ExternalLoginsJson)
                    ? new List<string>()
                    : JsonConvert.DeserializeObject<List<string>>(ExternalLoginsJson);
            }
            set
            {
                ExternalLoginsJson = JsonConvert.SerializeObject(value);
            }
        }

        public ICollection<Randevu> Randevular { get; set; }



     
        public ICollection<FotoOneri> FotoOneriler { get; set; }
    }
}
