﻿// Islem.cs
using WebKuaforProje.Models;

public class Islem
{
    public int IslemID { get; set; }
    public string IslemAdi { get; set; }
    public decimal Fiyat { get; set; }
    public string Aciklama { get; set; }

    public int SalonID { get; set; }
    public Salon Salon { get; set; } // İşlem bir salona ait

    public ICollection<Randevu> Randevular { get; set; } // İşlem birden fazla randevuda yer alabilir
}
