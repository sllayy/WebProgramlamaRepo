﻿
namespace WebKuaforProje.Models
{
    using WebKuaforProje.Models;

    public class Calisan
    {
        public int CalisanID { get; set; }
        public string FullName { get; set; }
        public string PhoneNumber { get; set; }
        public string Email { get; set; }
        // Uzmanlıklar tek bir string içinde tutuluyor (örneğin: "Saç Kesimi, Boyama")
        public string Uzmanlik { get; set; }

        // Uygunluk saatleri string olarak JSON formatında tutuluyor
        public string UygunlukSaatleri { get; set; }
        public int SalonID { get; set; }
        public Salon Salon { get; set; } // Her çalışan bir salona bağlı

        public ICollection<Randevu> Randevular { get; set; }
    }
}