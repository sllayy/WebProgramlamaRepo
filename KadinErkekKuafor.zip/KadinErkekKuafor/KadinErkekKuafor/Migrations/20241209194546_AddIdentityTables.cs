﻿using Microsoft.EntityFrameworkCore.Migrations;

#nullable disable

namespace KadinErkekKuafor.Migrations
{
    public partial class AddIdentityTables : Migration
    {
        protected override void Up(MigrationBuilder migrationBuilder)
        {

        }

        protected override void Down(MigrationBuilder migrationBuilder)
        {

        }
    }
}
