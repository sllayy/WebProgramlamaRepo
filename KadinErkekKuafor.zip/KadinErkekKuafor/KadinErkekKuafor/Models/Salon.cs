﻿namespace KuaforYonetimSistemi.Models
{
	public class Salon
	{
		public int SalonID { get; set; }
		public string Ad { get; set; }
		public string Adres { get; set; }
		public string Telefon { get; set; }
		public string CalismaSaatleri { get; set; }
	}
}
